extends Node2D

@onready var label = $Label

var speed := 50.0
var lifetime := 1.0

func setup(value: int):
	label.text = str(value)

func _process(delta):
	position.y -= speed * delta
	
	lifetime -= delta
	
	modulate.a = lifetime
	
	if lifetime <= 0:
		queue_free()
