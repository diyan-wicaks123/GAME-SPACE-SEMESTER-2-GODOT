extends CanvasLayer

class_name UI

@onready var center_container = $MarginContainer/CenterContainer
@onready var score_label = $MarginContainer/HBoxContainer/ScoreLabel
@onready var coins_label = $MarginContainer/HBoxContainer/CoinsLabel

@onready var popup = $ReaderPopup
@onready var lore = $LorePanel


func set_score(points: int):
	score_label.text = "SCORE: %d" % points


func set_coins(coins: int):
	coins_label.text = "COINS: %d" % coins


func on_finish():
	center_container.visible = true


func _on_button_ya_pressed():
	popup.visible = false
	lore.visible = true


func _on_button_tidak_pressed():
	popup.visible = false


func _on_button_tutup_pressed():
	lore.visible = false
