extends Area2D

@onready var popup = get_node("/root/main/UI/ReaderPopup")

func _on_body_entered(body):
	if body.name == "Player":
		popup.visible = true


func _on_body_exited(body):
	if body.name == "Player":
		popup.visible = false
