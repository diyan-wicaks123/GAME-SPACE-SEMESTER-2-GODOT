extends Area2D

class_name Fireball

@export var speed: float = 300
var direction: int = 1
@export var max_bounce: int = 3
var bounce_count: int = 0

func _ready():
	# Detect tabrakan dengan Area2D (Enemy)
	area_entered.connect(_on_area_entered)
	
	# Optional: detect tabrakan dengan body (tembok, pipe, dll)
	body_entered.connect(_on_body_entered)

func _process(delta):
	# Gerak lurus ke kanan/kiri
	position.x += speed * direction * delta

func _on_area_entered(area):
	# Kalau kena musuh
	if area is Enemy:
		area.die_from_hit()
		queue_free()

func _on_body_entered(body):
	bounce_count += 1
	direction *= -1
	
	position.x += 5 * direction
	
	if bounce_count >= max_bounce:
		queue_free()
