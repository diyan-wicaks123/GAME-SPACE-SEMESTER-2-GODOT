extends Area2D

@export var wind_force: Vector2 = Vector2(-1500, 0)

var objects_in_wind = []

func _ready():
	print("WindZone aktif")
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)

func _physics_process(delta):
	for obj in objects_in_wind:
		if obj and obj is RigidBody2D:
			obj.linear_velocity += wind_force * delta

func _on_body_entered(body):
	print("MASUK:", body.name)
	if body is RigidBody2D:
		if not objects_in_wind.has(body):
			objects_in_wind.append(body)

func _on_body_exited(body):
	print("KELUAR:", body.name)
	if body in objects_in_wind:
		objects_in_wind.erase(body)
